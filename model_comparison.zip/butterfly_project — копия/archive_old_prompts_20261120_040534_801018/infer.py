"""Sequential local inference with pinned weight revisions and resumable outputs."""
from __future__ import annotations

import argparse
import importlib.metadata
import json
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from common import (require, manifest, image_path, file_hash, digest, read_json,
                    read_jsonl, index_rows, photo_key, write_json, write_jsonl,
                    append_jsonl, xyxy_box, parse_qwen, validate_boxes)

MODEL_IDS = {"dino": "IDEA-Research/grounding-dino-tiny",
             "owlv2": "google/owlv2-base-patch16-ensemble",
             "qwen": "Qwen/Qwen3-VL-2B-Instruct"}
MLX_ID = "mlx-community/Qwen3-VL-2B-Instruct-4bit"
QWEN_PROMPT = '''Locate every adult butterfly in the image. Use one tight bounding box per butterfly,
including all visible wings, body, antennae and legs. For occluded or cut-off butterflies
box only the visible parts. Do not include moths, other insects, caterpillars, pupae or shadows.
Return ONLY a JSON array: [{"bbox_2d": [x_min, y_min, x_max, y_max], "label": "butterfly"}].
Coordinates must be relative to the complete image, normalized to the range 0 to 1000.
If there are no adult butterflies return []. Do not include explanations or Markdown.'''


def environment():
    versions = {}
    for name in ("torch", "transformers", "huggingface-hub", "Pillow", "mlx", "mlx-vlm"):
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            pass
    return {"python": sys.version, "platform": platform.platform(), "packages": versions}


def resolve_weights(model_id, revision):
    from huggingface_hub import snapshot_download
    path = Path(snapshot_download(repo_id=model_id, revision=revision,
                                 ignore_patterns=["*.bin", "*.onnx", "*.msgpack", "*.h5", "*.tflite"])).resolve()
    # Hub snapshots use an immutable commit hash as the directory name.
    sha = path.name
    require(len(sha) == 40 and all(c in "0123456789abcdef" for c in sha),
            "Cannot determine immutable model revision")
    return path, sha


class TorchDetector:
    def __init__(self, weights, config):
        import torch
        from transformers import AutoProcessor, AutoModelForZeroShotObjectDetection, Owlv2ForObjectDetection
        self.torch, self.config = torch, config
        self.device = config["device"]
        self.processor = AutoProcessor.from_pretrained(str(weights), local_files_only=True)
        cls = Owlv2ForObjectDetection if config["model"] == "owlv2" else AutoModelForZeroShotObjectDetection
        self.model = cls.from_pretrained(str(weights), local_files_only=True).to(self.device).eval()

    def sync(self):
        if self.device == "mps":
            self.torch.mps.synchronize()
        elif self.device == "cuda":
            self.torch.cuda.synchronize()

    def predict(self, image):
        c = self.config
        text = [[c["prompt"]]] if c["model"] == "owlv2" else c["prompt"]
        inputs = self.processor(images=image, text=text, return_tensors="pt").to(self.device)
        with self.torch.inference_mode():
            outputs = self.model(**inputs)
        kwargs = dict(threshold=c["score_floor"], target_sizes=[(image.height, image.width)])
        if c["model"] == "dino":
            result = self.processor.post_process_grounded_object_detection(
                outputs, inputs.input_ids, text_threshold=c["text_threshold"], **kwargs)[0]
        else:
            result = self.processor.post_process_grounded_object_detection(outputs, **kwargs)[0]
        boxes = [xyxy_box(coords, image.width, image.height, score)
                 for coords, score in zip(result["boxes"].detach().cpu().tolist(),
                                          result["scores"].detach().cpu().tolist())]
        return boxes, None


class TorchQwen:
    def __init__(self, weights, config):
        import torch
        from transformers import AutoProcessor, Qwen3VLForConditionalGeneration
        self.torch, self.config, self.device = torch, config, config["device"]
        self.processor = AutoProcessor.from_pretrained(str(weights), local_files_only=True)
        # No training, remote code, or API calls. Float32 on CPU; half precision on accelerators.
        dtype = torch.float32 if self.device == "cpu" else torch.float16
        self.model = Qwen3VLForConditionalGeneration.from_pretrained(
            str(weights), local_files_only=True, torch_dtype=dtype,
            attn_implementation="eager").to(self.device).eval()

    sync = TorchDetector.sync

    def predict(self, image):
        messages = [{"role": "user", "content": [{"type": "image", "image": image},
                     {"type": "text", "text": self.config["prompt"]}]}]
        text = self.processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = self.processor(text=[text], images=[image], return_tensors="pt").to(self.device)
        with self.torch.inference_mode():
            output = self.model.generate(**inputs, do_sample=False, max_new_tokens=self.config["max_tokens"])
        tokens = output[:, inputs["input_ids"].shape[1]:]
        raw = self.processor.batch_decode(tokens, skip_special_tokens=True, clean_up_tokenization_spaces=False)[0]
        return raw, "qwen_json"


class MLXQwen:
    def __init__(self, weights, config):
        import mlx.core as mx
        from mlx_vlm import load, generate
        from mlx_vlm.prompt_utils import apply_chat_template
        from mlx_vlm.utils import load_config
        self.mx, self.generate, self.template = mx, generate, apply_chat_template
        self.model, self.processor = load(str(weights))
        self.model_config = load_config(str(weights))
        self.config = config

    def sync(self):
        self.mx.synchronize()

    def predict(self, image):
        text = self.template(self.processor, self.model_config, self.config["prompt"], num_images=1)
        result = self.generate(self.model, self.processor, text, image=[image],
                               max_tokens=self.config["max_tokens"], temperature=0., verbose=False)
        raw = result if isinstance(result, str) else getattr(result, "text", None)
        require(isinstance(raw, str), "Unexpected MLX generate return type")
        return raw, "qwen_json"


def load_backend(weights, config):
    if config["backend"] == "mlx":
        return MLXQwen(weights, config)
    if config["model"] == "qwen":
        return TorchQwen(weights, config)
    return TorchDetector(weights, config)


def run(args):
    from PIL import Image, ImageOps
    rows = manifest(args.manifest)
    output = Path(args.output)
    require(args.limit is None or args.limit > 0, "--limit must be positive")
    require(not args.retry_errors or args.resume, "--retry-errors requires --resume")
    require(not args.selection or not any((args.model, args.model_id, args.prompt_file, args.revision)),
            "Use only --selection for a frozen configuration; do not override its model or prompt")
    if args.selection:
        selected = read_json(args.selection)
        require(selected.get("schema_version") == 1, "Unknown selection schema")
        config = selected["inference"]
        weights, sha = resolve_weights(config["model_id"], config["revision"])
        require(sha == config["revision"], "Weight revision mismatch")
    else:
        require(args.model in MODEL_IDS, "Provide --model dino, owlv2 or qwen")
        require(args.backend != "mlx" or args.model == "qwen", "MLX backend is only for Qwen")
        model_id = args.model_id or (MLX_ID if args.backend == "mlx" else MODEL_IDS[args.model])
        resume_meta = output / "run.json"
        revision = args.revision
        if args.resume and revision is None and resume_meta.exists():
            revision = read_json(resume_meta)["inference"]["revision"]
        weights, sha = resolve_weights(model_id, revision or "main")
        device = args.device
        if args.backend == "mlx":
            device = "mlx"
        elif device == "auto":
            import torch
            device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
        prompt = QWEN_PROMPT if args.model == "qwen" else "butterfly." if args.model == "dino" else "a photo of a butterfly"
        if args.prompt_file:
            prompt = Path(args.prompt_file).read_text(encoding="utf-8").strip()
            require(prompt, "Empty prompt")
        config = dict(model=args.model, model_id=model_id, revision=sha, backend=args.backend,
                      device=device, prompt=prompt, score_floor=args.score_floor,
                      text_threshold=args.text_threshold, max_tokens=args.max_tokens,
                      max_side=args.max_side, orientation="exif_transpose", color="RGB",
                      resize="Pillow LANCZOS thumbnail, preserve aspect ratio, no upscale",
                      seed=0)
    require(0 <= config["score_floor"] <= 1 and 0 <= config["text_threshold"] <= 1,
            "Thresholds must be in [0,1]")
    require(config["max_side"] >= 32 and config["max_tokens"] > 0, "Invalid size/token limit")
    output.mkdir(parents=True, exist_ok=True)
    config_hash = digest(config)
    # Hash every local photo, including during resume. Changed bytes cannot reuse old outputs.
    fingerprints = {}
    for row in rows:
        p = image_path(args.manifest, row)
        fingerprints[photo_key(row["photo_id"])] = file_hash(p) if p.is_file() else "MISSING"
    data_signature = digest({"manifest": file_hash(args.manifest), "images": fingerprints})
    metadata_path = output / "run.json"
    predictions_path = output / "predictions.jsonl"
    metadata = dict(schema_version=1, inference=config, config_hash=config_hash,
                    dataset_signature=data_signature, manifest_sha256=file_hash(args.manifest),
                    image_sha256=fingerprints, environment=environment(), photos=len(rows),
                    created_at=datetime.now(timezone.utc).isoformat())
    existing = {}
    if metadata_path.exists():
        require(args.resume, "Run already exists; add --resume or choose a different output folder")
        old = read_json(metadata_path)
        require(old["config_hash"] == config_hash, "Resume configuration changed")
        require(old["dataset_signature"] == data_signature, "Manifest or image bytes changed")
        require(old["environment"] == metadata["environment"], "Environment changed; use a new output folder")
        metadata = old
        existing = index_rows(read_jsonl(predictions_path)) if predictions_path.exists() else {}
        require(not set(existing) - set(fingerprints), "Run contains unknown photo IDs")
        for row in existing.values():
            require(row.get("config_hash") == config_hash, "Mixed configurations in predictions")
    else:
        require(not any(output.iterdir()), "Output folder must be empty for a new run")
        write_json(metadata_path, metadata)
    selected_rows = rows[:args.limit] if args.limit else rows
    pending = [r for r in selected_rows if photo_key(r["photo_id"]) not in existing
               or (args.retry_errors and existing[photo_key(r["photo_id"])].get("error") is not None)]
    if not pending:
        print("All selected images already processed; nothing to do.")
        return
    if config["backend"] == "torch":
        import torch
        torch.manual_seed(config["seed"])
    started = time.perf_counter()
    backend = load_backend(weights, config)
    backend.sync()
    metadata.setdefault("load_events", []).append({"seconds": time.perf_counter()-started,
                                                  "at": datetime.now(timezone.utc).isoformat()})
    write_json(metadata_path, metadata)
    for i, row in enumerate(pending, 1):
        key, raw = photo_key(row["photo_id"]), None
        record = {"photo_id": row["photo_id"], "boxes": None, "error": None,
                  "config_hash": config_hash, "image_sha256": fingerprints[key]}
        backend.sync()
        started = time.perf_counter()
        try:
            with Image.open(image_path(args.manifest, row)) as im:
                image = ImageOps.exif_transpose(im).convert("RGB")
            record["original_size"] = list(image.size)
            image.thumbnail((config["max_side"], config["max_side"]), Image.Resampling.LANCZOS)
            record["input_size"] = list(image.size)
            value, fmt = backend.predict(image)
            if fmt == "qwen_json":
                raw = value
                boxes = parse_qwen(raw)
            else:
                boxes = value
            validate_boxes(boxes)
            backend.sync()
            record["boxes"] = boxes
        except Exception as e:
            record["error"] = {"type": type(e).__name__, "message": str(e)}
        record["seconds"] = time.perf_counter() - started
        record["at"] = datetime.now(timezone.utc).isoformat()
        if raw is not None:
            record["raw_response"] = raw
        # The append-only journal retains every failed/successful attempt.
        append_jsonl(output / "attempts.jsonl", record)
        existing[key] = record
        write_jsonl(predictions_path, [existing[photo_key(r["photo_id"])] for r in rows
                                     if photo_key(r["photo_id"]) in existing])
        print(f"{i}/{len(pending)} photo={key} " +
              (f"ERROR {record['error']}" if record["error"] else f"boxes={len(record['boxes'])}") +
              f" seconds={record['seconds']:.2f}", flush=True)
    failures = sum(r.get("error") is not None for r in existing.values())
    print(f"Saved {len(existing)}/{len(rows)} photos; errors={failures}; {predictions_path}")
    if failures:
        raise SystemExit(2)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--manifest", required=True); p.add_argument("--output", required=True)
    p.add_argument("--model", choices=list(MODEL_IDS)); p.add_argument("--selection")
    p.add_argument("--backend", choices=["torch", "mlx"], default="torch")
    p.add_argument("--model-id"); p.add_argument("--revision"); p.add_argument("--prompt-file")
    p.add_argument("--device", choices=["auto", "cpu", "mps", "cuda"], default="auto")
    p.add_argument("--score-floor", type=float, default=.01)
    p.add_argument("--text-threshold", type=float, default=.25)
    p.add_argument("--max-side", type=int, default=1024); p.add_argument("--max-tokens", type=int, default=2048)
    p.add_argument("--limit", type=int); p.add_argument("--resume", action="store_true")
    p.add_argument("--retry-errors", action="store_true")
    run(p.parse_args())


if __name__ == "__main__":
    main()
