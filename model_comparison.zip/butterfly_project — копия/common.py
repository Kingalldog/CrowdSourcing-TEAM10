"""Shared strict data contracts; normalized left/top/width/height everywhere."""
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def number(value):
    require(isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value), f"Expected finite number, got {value!r}")
    return float(value)


def photo_key(value):
    require(isinstance(value, (int, str)) and not isinstance(value, bool), "Invalid photo_id")
    require(str(value).isdigit() and int(value) > 0, f"photo_id must be a positive integer: {value!r}")
    return str(int(value))


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     allow_nan=False).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_jsonl(path):
    result = []
    for i, line in enumerate(Path(path).read_text(encoding="utf-8-sig").splitlines(), 1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
            require(isinstance(row, dict), "Row must be an object")
            result.append(row)
        except (ValueError, TypeError) as e:
            raise ValueError(f"{path}:{i}: {e}") from e
    return result


def write_json(path, value):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    temporary = p.with_name(p.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(temporary, p)


def write_jsonl(path, rows):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    temporary = p.with_name(p.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(temporary, p)


def append_jsonl(path, row):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
        f.flush()
        os.fsync(f.fileno())


def index_rows(rows):
    result = {}
    for row in rows:
        key = photo_key(row.get("photo_id"))
        require(key not in result, f"Duplicate photo_id: {key}")
        result[key] = row
    return result


def manifest(path):
    rows = read_jsonl(path)
    require(rows, "Manifest is empty")
    index_rows(rows)
    for row in rows:
        require(isinstance(row.get("image_path"), str) and row["image_path"],
                f"Missing image_path: {row['photo_id']}")
        require(isinstance(row.get("group", "ungrouped"), str), "group must be a string")
        row["photo_id"] = int(photo_key(row["photo_id"]))
    return rows


def image_path(manifest_path, row):
    p = Path(row["image_path"]).expanduser()
    return p.resolve() if p.is_absolute() else (Path(manifest_path).resolve().parent / p).resolve()


def validate_box(box):
    require(isinstance(box, dict), "Box must be an object")
    x, y, w, h = [number(box.get(k)) for k in ("left", "top", "width", "height")]
    eps = 1e-7
    require(0 <= x <= 1 and 0 <= y <= 1 and 0 < w <= 1 and 0 < h <= 1
            and x + w <= 1 + eps and y + h <= 1 + eps, f"Invalid normalized box: {box}")
    if "score" in box:
        require(0 <= number(box["score"]) <= 1, "Invalid confidence score")
    return box


def validate_boxes(boxes):
    require(isinstance(boxes, list), "boxes must be a list; failures must be handled separately")
    for box in boxes:
        validate_box(box)
    return boxes


def xyxy_box(coords, width, height, score=None):
    x1, y1, x2, y2 = [number(x) for x in coords]
    require(x2 > x1 and y2 > y1, "Reversed or degenerate xyxy")
    x1, x2 = max(0., min(1., x1 / width)), max(0., min(1., x2 / width))
    y1, y2 = max(0., min(1., y1 / height)), max(0., min(1., y2 / height))
    box = dict(left=x1, top=y1, width=x2-x1, height=y2-y1)
    if score is not None:
        box["score"] = float(score)
    return validate_box(box)


def iou(a, b):
    x = max(0., min(a["left"]+a["width"], b["left"]+b["width"]) - max(a["left"], b["left"]))
    y = max(0., min(a["top"]+a["height"], b["top"]+b["height"]) - max(a["top"], b["top"]))
    intersection = x * y
    return intersection / (a["width"]*a["height"] + b["width"]*b["height"] - intersection)


def maximum_matching(predicted, truth, threshold):
    """Maximum cardinality bipartite matching, not greedy IoU matching."""
    adjacency = [[j for j, g in enumerate(truth) if iou(p, g) >= threshold] for p in predicted]
    owner = {}
    # Iterative augmenting paths avoid recursion limits on crowded frames.
    for root in range(len(predicted)):
        queue, parent, seen_gold = [root], {}, set()
        found = None
        for p in queue:
            for g in adjacency[p]:
                if g in seen_gold:
                    continue
                seen_gold.add(g)
                parent[g] = p
                if g not in owner:
                    found = g
                    break
                queue.append(owner[g])
            if found is not None:
                break
        if found is not None:
            g = found
            while True:
                p = parent[g]
                old = next((j for j, v in owner.items() if v == p), None)
                owner[g] = p
                if old is None:
                    break
                del owner[old]
                g = old
    return len(owner)


def postprocess(boxes, threshold=0., nms=None):
    require(0 <= threshold <= 1, "threshold must be in [0,1]")
    require(nms is None or 0 <= nms <= 1, "NMS IoU must be in [0,1]")
    validate_boxes(boxes)
    # Generative model boxes have no calibrated scores: threshold 0 is required.
    require(not threshold or all("score" in b for b in boxes),
            "Confidence threshold is unavailable for unscored boxes (Qwen)")
    selected = sorted((b for b in boxes if b.get("score", 1.) >= threshold),
                      key=lambda b: -b.get("score", 1.))
    kept = []
    for b in selected:
        if nms is None or all(iou(b, other) <= nms for other in kept):
            kept.append(b)
    return kept


def parse_qwen(text):
    """Strict JSON, optionally wrapped in one Markdown fence; no coordinate guessing."""
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        require(lines[-1].strip() == "```", "Unterminated JSON fence")
        text = "\n".join(lines[1:-1])
    parsed = json.loads(text)
    if isinstance(parsed, dict):
        require(set(parsed) == {"boxes"}, "Expected only a boxes key")
        parsed = parsed["boxes"]
    require(isinstance(parsed, list), "Expected a JSON array")
    boxes = []
    for item in parsed:
        require(isinstance(item, dict) and "bbox_2d" in item, "Missing bbox_2d")
        coords = item["bbox_2d"]
        require(isinstance(coords, list) and len(coords) == 4, "Expected four coordinates")
        require(all(0 <= number(v) <= 1000 for v in coords), "Qwen coordinates must be in [0,1000]")
        boxes.append(xyxy_box(coords, 1000, 1000))
    return boxes


def save_csv(path, rows):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        p.write_text("", encoding="utf-8")
        return
    with p.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
