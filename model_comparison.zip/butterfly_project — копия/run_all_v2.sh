#!/bin/bash
set -u
cd -- "$(dirname -- "$0")"
caffeinate -i &
WAKE_PID=$!
trap 'kill "$WAKE_PID" 2>/dev/null || true' EXIT
mkdir -p logs
echo "Starting dino (415 photos, new prompts)"
.venv-detectors/bin/python -u infer.py --manifest data/photos_full.jsonl --model dino --device cpu --revision a2bb814dd30d776dcf7e30523b00659f4f141c71 --prompt-file prompts/dino_v2.txt --output runs/dino_full --resume --retry-errors > logs/dino_v2.log 2>&1
STATUS=$?; echo "dino finished: exit=$STATUS; see logs/dino_v2.log"
echo "Starting owlv2 (415 photos, new prompts)"
.venv-detectors/bin/python -u infer.py --manifest data/photos_full.jsonl --model owlv2 --device cpu --revision cfd3195ba4ea9592eec887ded089f4c08eff231d --prompt-file prompts/owlv2_v2.txt --output runs/owlv2_full --resume --retry-errors > logs/owlv2_v2.log 2>&1
STATUS=$?; echo "owlv2 finished: exit=$STATUS; see logs/owlv2_v2.log"
echo "Starting qwen (415 photos, new prompts)"
.venv-mlx/bin/python -u infer.py --manifest data/photos_full.jsonl --model qwen --backend mlx --revision 9c4f5209e57b31f4b9dfba735de3fb983739c9cc --prompt-file prompts/qwen_v2.txt --output runs/qwen_full --resume --retry-errors > logs/qwen_v2.log 2>&1
STATUS=$?; echo "qwen finished: exit=$STATUS; see logs/qwen_v2.log"
