"""Import an existing photo list, audit images, and finalize human golden decisions."""
from __future__ import annotations

import argparse
import csv
import io
import json
import urllib.request
from pathlib import Path
from datetime import datetime, timezone

from common import (require, manifest, image_path, photo_key, file_hash, read_jsonl,
                    index_rows, validate_boxes, write_json, write_jsonl)


def import_csv(args):
    source = Path(args.input).resolve()
    output = Path(args.output).resolve()
    with source.open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f, delimiter="\t" if args.tsv else ",")
        require(args.id_column in (reader.fieldnames or []), "ID column not found")
        for column in (args.path_column, args.group_column):
            require(not column or column in reader.fieldnames, f"Column not found: {column}")
        rows = []
        for raw in reader:
            key = photo_key(raw[args.id_column])
            local = raw.get(args.path_column, "") if args.path_column else ""
            if local:
                p = Path(local).expanduser()
                p = p if p.is_absolute() else source.parent / p
            else:
                p = output.parent / "images" / f"{key}.jpg"
            import os
            row = {"photo_id": int(key), "image_path": os.path.relpath(p.resolve(), output.parent),
                   "group": raw.get(args.group_column, "ungrouped") if args.group_column else "ungrouped"}
            for field, column in (("image_url", args.url_column), ("license", args.license_column),
                                  ("source_url", args.source_column), ("author", args.author_column)):
                if column:
                    require(column in raw, f"Column not found: {column}")
                    row[field] = raw[column]
            rows.append(row)
    require(rows, "No photos found")
    index_rows(rows)
    write_jsonl(output, rows)
    print(f"Saved {len(rows)} photos to {output}. No rows were silently excluded.")


def check_images(args):
    from PIL import Image
    rows = manifest(args.manifest)
    reports, hashes = [], {}
    for row in rows:
        p = image_path(args.manifest, row)
        report = {"photo_id": row["photo_id"], "path": str(p), "error": None}
        try:
            if args.require_cc0:
                require(str(row.get("license", "")).lower() == "cc0", "Missing/non-CC0 photo license")
                require(row.get("source_url"), "Missing source_url")
            if args.download and not p.exists():
                url = row.get("image_url", "")
                require(url.startswith("https://"), "Missing HTTPS image_url")
                with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "ButterflyResearch/1.0"}), timeout=60) as response:
                    data = response.read(50 * 1024 * 1024 + 1)
                require(len(data) <= 50*1024*1024, "Image exceeds 50 MiB")
                with Image.open(io.BytesIO(data)) as im:
                    im.load()
                p.parent.mkdir(parents=True, exist_ok=True)
                tmp = p.with_name(p.name + ".download")
                tmp.write_bytes(data)
                tmp.replace(p)
            with Image.open(p) as im:
                im.load()
                report.update(width=im.width, height=im.height,
                              exif_orientation=im.getexif().get(274, 1))
            report["sha256"] = file_hash(p)
            report["duplicate_of"] = hashes.get(report["sha256"])
            hashes.setdefault(report["sha256"], row["photo_id"])
        except Exception as e:
            report["error"] = f"{type(e).__name__}: {e}"
        reports.append(report)
    errors = sum(r["error"] is not None for r in reports)
    duplicates = sum(r.get("duplicate_of") is not None for r in reports)
    write_json(args.output, {"photos": len(rows), "errors": errors,
                             "exact_duplicates": duplicates, "images": reports})
    print(f"Photos: {len(rows)}, errors: {errors}, exact duplicates: {duplicates}. Report: {args.output}")
    if errors or duplicates:
        raise SystemExit(2)


def template(args):
    rows = manifest(args.manifest)
    proposals = index_rows(read_jsonl(args.proposals)) if args.proposals else {}
    require(not set(proposals) - {photo_key(r["photo_id"]) for r in rows}, "Proposals contain unknown IDs")
    decisions = []
    for row in rows:
        proposed = proposals.get(photo_key(row["photo_id"]), {}).get("boxes")
        if proposed is not None:
            validate_boxes(proposed)
        decisions.append(dict(photo_id=row["photo_id"], boxes=proposed, original_boxes=proposed,
                              approved=False, checked_by="", author_id="", reviewer_ids=[],
                              evidence=[], reason="", model_assisted=False, model_assistance_note=""))
    require(not Path(args.output).exists(), "Decision file exists; use a new filename")
    write_jsonl(args.output, decisions)
    print(f"Created {len(decisions)} pending decisions. null means undecided; [] means confirmed absence.")


def finalize(args):
    rows = manifest(args.manifest)
    decisions = index_rows(read_jsonl(args.decisions))
    expected = {photo_key(r["photo_id"]) for r in rows}
    require(set(decisions) == expected, "Decision IDs must exactly match the complete manifest")
    gold, audit = [], []
    for row in rows:
        key = photo_key(row["photo_id"])
        d = decisions[key]
        require(d.get("approved") is True, f"{key}: pending human decision")
        validate_boxes(d.get("boxes"))
        require(isinstance(d.get("checked_by"), str) and d["checked_by"].strip(), f"{key}: missing final checker")
        require(isinstance(d.get("reason"), str) and d["reason"].strip(), f"{key}: missing explanation")
        require(isinstance(d.get("evidence"), list) and d["evidence"]
                and all(isinstance(x, str) and x.strip() for x in d["evidence"]), f"{key}: missing evidence references")
        require(isinstance(d.get("author_id"), str) and d["author_id"].strip(), f"{key}: missing annotation author")
        reviewers = d.get("reviewer_ids")
        require(isinstance(reviewers, list) and reviewers
                and all(isinstance(x, str) and x.strip() for x in reviewers), f"{key}: missing human reviewers")
        require(d["author_id"] not in reviewers, f"{key}: self-review detected")
        require(isinstance(d.get("model_assisted"), bool), f"{key}: model_assisted must be boolean")
        require(not d["model_assisted"] or d.get("model_assistance_note"), f"{key}: describe model assistance")
        if d.get("original_boxes") is not None:
            validate_boxes(d["original_boxes"])
        boxes = [{k: b[k] for k in ("left", "top", "width", "height")} for b in d["boxes"]]
        gold.append({"photo_id": row["photo_id"], "boxes": boxes, "error": None})
        audit.append(d)
    destination = Path(args.output)
    require(not destination.exists(), "Golden file exists; use a versioned output filename")
    write_jsonl(destination, gold)
    write_json(str(destination)+".audit.json", {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "manifest_sha256": file_hash(args.manifest), "decisions_sha256": file_hash(args.decisions),
        "golden_sha256": file_hash(destination),
        "note": "Evidence references and reviewer identities are declared by the team, not independently verified by this script.",
        "decisions": audit})
    print(f"Golden set: {len(gold)} photos; audit saved alongside {destination}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("import-csv", help="Convert your existing fixed photo list")
    p.add_argument("--input", required=True); p.add_argument("--output", required=True)
    p.add_argument("--id-column", default="photo_id"); p.add_argument("--path-column")
    p.add_argument("--url-column"); p.add_argument("--group-column"); p.add_argument("--license-column")
    p.add_argument("--source-column"); p.add_argument("--author-column"); p.add_argument("--tsv", action="store_true")
    p.set_defaults(func=import_csv)
    p = sub.add_parser("check", help="Validate/download photos, report byte-identical duplicates")
    p.add_argument("--manifest", required=True); p.add_argument("--output", required=True)
    p.add_argument("--download", action="store_true"); p.add_argument("--require-cc0", action="store_true")
    p.set_defaults(func=check_images)
    p = sub.add_parser("template", help="Create pending human golden decisions")
    p.add_argument("--manifest", required=True); p.add_argument("--proposals")
    p.add_argument("--output", required=True); p.set_defaults(func=template)
    p = sub.add_parser("finalize", help="Validate all human decisions and freeze golden set")
    p.add_argument("--manifest", required=True); p.add_argument("--decisions", required=True)
    p.add_argument("--output", required=True); p.set_defaults(func=finalize)
    args = parser.parse_args(); args.func(args)


if __name__ == "__main__":
    main()
