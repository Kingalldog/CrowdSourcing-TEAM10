"""Render predictions / human golden boxes for qualitative error analysis."""
import argparse
from pathlib import Path
from PIL import Image, ImageOps, ImageDraw
from common import manifest, image_path, read_jsonl, index_rows, photo_key, postprocess, require


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--manifest", required=True); p.add_argument("--predictions", required=True)
    p.add_argument("--golden"); p.add_argument("--output", required=True)
    p.add_argument("--threshold", type=float, default=0.); p.add_argument("--nms", type=float)
    p.add_argument("--limit", type=int, default=20)
    args = p.parse_args()
    require(args.limit > 0, "limit must be positive")
    predictions = index_rows(read_jsonl(args.predictions))
    gold = index_rows(read_jsonl(args.golden)) if args.golden else {}
    dest = Path(args.output); dest.mkdir(parents=True, exist_ok=True)
    for row in manifest(args.manifest)[:args.limit]:
        key = photo_key(row["photo_id"])
        with Image.open(image_path(args.manifest, row)) as im:
            image = ImageOps.exif_transpose(im).convert("RGB")
        image.thumbnail((1400, 1400), Image.Resampling.LANCZOS)
        draw = ImageDraw.Draw(image)
        pred = predictions.get(key)
        if pred is None or pred.get("error") is not None:
            text = "MISSING PREDICTION" if pred is None else "PROCESSING ERROR"
            draw.rectangle((0, 0, 240, 24), fill="black")
            draw.text((4, 4), text, fill="red")
            predicted = []
        else:
            predicted = postprocess(pred["boxes"], args.threshold, args.nms)
        for label, boxes, color in (("GT", gold.get(key, {}).get("boxes", []), "lime"),
                                     ("PRED", predicted, "red")):
            for b in boxes:
                x, y = b["left"]*image.width, b["top"]*image.height
                draw.rectangle((x, y, x+b["width"]*image.width, y+b["height"]*image.height), outline=color, width=3)
                draw.text((x+3, y+3), label + (f" {b['score']:.2f}" if "score" in b else ""), fill=color,
                          stroke_width=1, stroke_fill="black")
        image.save(dest/f"{key}.jpg")
    print(f"Saved overlays to {dest}; green=golden, red=predictions")


if __name__ == "__main__":
    main()
