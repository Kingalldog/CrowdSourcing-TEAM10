"""Whole-dataset metrics, one-factor experiments, selection, strict Contest export."""
from __future__ import annotations

import argparse
from pathlib import Path
from statistics import mean

from common import (require, manifest, photo_key, read_json, read_jsonl, index_rows,
                    file_hash, digest, number, validate_boxes, maximum_matching,
                    postprocess, write_json, write_jsonl, save_csv)


def inputs(manifest_path, golden_path, run_dir):
    rows = manifest(manifest_path)
    truth = index_rows(read_jsonl(golden_path))
    expected = {photo_key(r["photo_id"]) for r in rows}
    require(set(truth) == expected, "Golden IDs must exactly match the whole manifest")
    for key, row in truth.items():
        require(row.get("error") is None, f"Golden {key} contains an error")
        validate_boxes(row.get("boxes"))
    run = Path(run_dir)
    metadata = read_json(run / "run.json")
    require(metadata["manifest_sha256"] == file_hash(manifest_path), "Run was made on a different manifest")
    predictions = index_rows(read_jsonl(run / "predictions.jsonl"))
    require(not set(predictions) - expected, "Unknown prediction IDs")
    require(metadata["config_hash"] == digest(metadata["inference"]), "Invalid run configuration hash")
    for key, row in predictions.items():
        require("error" in row, f"{key}: missing error status")
        require(row.get("config_hash") == metadata["config_hash"], "Mixed prediction configurations")
        require(row.get("image_sha256") == metadata["image_sha256"][key], "Image hash mismatch")
        require(number(row.get("seconds")) >= 0, "Invalid timing")
        if row["error"] is None:
            validate_boxes(row.get("boxes"))
        else:
            require(row.get("boxes") is None, "Failed prediction must use boxes=null")
    return rows, truth, predictions, metadata


def summarize(details):
    result = dict(photos=len(details), technical_errors=sum(r["technical_error"] for r in details),
                  negative_photos=sum(r["truth_boxes"] == 0 for r in details),
                  negative_photos_with_fp=sum(r["truth_boxes"] == 0 and r["predicted_boxes"] > 0 for r in details),
                  fp_on_negative_photos=sum(r["predicted_boxes"] for r in details if r["truth_boxes"] == 0),
                  photos_with_detection_errors=sum(r["fp_50"] > 0 or r["fn_50"] > 0 for r in details))
    result["negative_false_positive_rate"] = (result["negative_photos_with_fp"] / result["negative_photos"]
                                               if result["negative_photos"] else None)
    for suffix in ("50", "75"):
        tp, fp, fn = [sum(r[f"{name}_{suffix}"] for r in details) for name in ("tp", "fp", "fn")]
        result[f"iou_{suffix}"] = dict(tp=tp, fp=fp, fn=fn,
            precision=tp/(tp+fp) if tp+fp else 0., recall=tp/(tp+fn) if tp+fn else 0.,
            f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.)
    attempted = [r["seconds"] for r in details if r["seconds"] is not None]
    successful = [r["seconds"] for r in details if not r["technical_error"]]
    result["timing"] = dict(total_attempted_seconds=sum(attempted),
                            mean_attempt_seconds=mean(attempted) if attempted else None,
                            mean_success_seconds=mean(successful) if successful else None,
                            timed_photos=len(attempted))
    return result


def score(rows, truth, predictions, threshold, nms):
    details = []
    for row in rows:
        key = photo_key(row["photo_id"])
        g = truth[key]["boxes"]
        p = predictions.get(key)
        error = p is None or p.get("error") is not None
        # Failed images stay in denominator: all their GT objects become FN.
        boxes = [] if error else postprocess(p["boxes"], threshold, nms)
        record = dict(photo_id=row["photo_id"], group=row.get("group", "ungrouped"),
                      truth_boxes=len(g), predicted_boxes=len(boxes), technical_error=int(error),
                      seconds=p["seconds"] if p else None,
                      error=str(p.get("error")) if p and error else "missing_prediction" if p is None else "")
        for t, suffix in ((.5, "50"), (.75, "75")):
            tp = maximum_matching(boxes, g, t)
            record.update({f"tp_{suffix}": tp, f"fp_{suffix}": len(boxes)-tp, f"fn_{suffix}": len(g)-tp})
        details.append(record)
    groups = {group: summarize([r for r in details if r["group"] == group])
              for group in sorted({r["group"] for r in details})}
    return summarize(details), groups, details


def make_report(args, threshold, nms):
    rows, truth, predictions, metadata = inputs(args.manifest, args.golden, args.run)
    config = metadata["inference"]
    if config["model"] == "qwen":
        require(threshold == 0., "Qwen does not provide calibrated object scores; use --threshold 0")
    else:
        require(threshold >= config["score_floor"], "Threshold is below saved score floor; rerun inference with lower floor")
    overall, groups, details = score(rows, truth, predictions, threshold, nms)
    report = dict(schema_version=1, model=config["model"], inference=config,
                  postprocess={"threshold": threshold, "nms_iou": nms},
                  manifest_sha256=file_hash(args.manifest), golden_sha256=file_hash(args.golden),
                  dataset_signature=metadata["dataset_signature"],
                  prediction_sha256=file_hash(Path(args.run)/"predictions.jsonl"),
                  overall=overall, groups=groups,
                  eligible_for_selection=overall["technical_errors"] == 0,
                  metric_policy="micro maximum-cardinality matching; errors retain GT FN; zero denominator=0",
                  timing_policy="decode+resize+processor+forward+postprocess; excludes weights; latest attempt per photo",
                  run_load_events=metadata.get("load_events", []), environment=metadata["environment"])
    return report, details


def score_command(args):
    report, details = make_report(args, args.threshold, args.nms)
    write_json(args.output, report)
    save_csv(str(args.output)+".per_image.csv", details)
    print(f"F1@0.5={report['overall']['iou_50']['f1']:.4f}; F1@0.75={report['overall']['iou_75']['f1']:.4f}; "
          f"technical_errors={report['overall']['technical_errors']}")


def experiment(args):
    require(args.hypothesis.strip(), "State the hypothesis before running the experiment")
    plan = dict(factor=args.factor, values=args.values, hypothesis=args.hypothesis,
                fixed_threshold=args.threshold, fixed_nms=args.nms)
    dest = Path(args.output)
    require(not dest.exists(), "Experiment directory exists; use a new name")
    dest.mkdir(parents=True)
    write_json(dest/"plan.json", plan)
    leaderboard = []
    for i, value in enumerate(args.values):
        threshold = value if args.factor == "threshold" else args.threshold
        nms = value if args.factor == "nms" else args.nms
        report, details = make_report(args, threshold, nms)
        report["experiment"] = plan
        write_json(dest/f"report_{i}.json", report)
        save_csv(dest/f"per_image_{i}.csv", details)
        leaderboard.append(dict(value=value, f1_50=report["overall"]["iou_50"]["f1"],
                                f1_75=report["overall"]["iou_75"]["f1"],
                                technical_errors=report["overall"]["technical_errors"]))
    save_csv(dest/"comparison.csv", leaderboard)
    print(f"Saved {len(leaderboard)} one-factor configurations to {dest}")


def select(args):
    reports = [read_json(p) for p in args.reports]
    require(reports, "No reports")
    require({r["model"] for r in reports} >= {"dino", "owlv2", "qwen"},
            "Comparison must include all three required models")
    require(len({(r["manifest_sha256"], r["golden_sha256"], r["dataset_signature"]) for r in reports}) == 1,
            "Reports must use the same complete dataset and golden version")
    require(all(r["eligible_for_selection"] for r in reports),
            "Resolve technical errors in all three models before selection")
    ranked = sorted(reports, key=lambda r: (-r["overall"]["iou_50"]["f1"],
                    r["overall"]["timing"]["mean_success_seconds"]))
    best = ranked[0]
    write_json(args.output, dict(schema_version=1, inference=best["inference"],
        postprocess=best["postprocess"], selected_by="max micro F1@IoU 0.5; tie=lower mean successful image time",
        validation_f1_50=best["overall"]["iou_50"]["f1"], manifest_sha256=best["manifest_sha256"],
        golden_sha256=best["golden_sha256"], environment=best["environment"],
        compared_reports=[{"path": str(p), "sha256": file_hash(p)} for p in args.reports]))
    save_csv(str(args.output)+".leaderboard.csv", [dict(model=r["model"],
        threshold=r["postprocess"]["threshold"], nms=r["postprocess"]["nms_iou"],
        precision=r["overall"]["iou_50"]["precision"], recall=r["overall"]["iou_50"]["recall"],
        f1_50=r["overall"]["iou_50"]["f1"], f1_75=r["overall"]["iou_75"]["f1"],
        fp=r["overall"]["iou_50"]["fp"], fn=r["overall"]["iou_50"]["fn"],
        negative_fp=r["overall"]["fp_on_negative_photos"],
        mean_seconds=r["overall"]["timing"]["mean_success_seconds"]) for r in ranked])
    print(f"Selected {best['model']}; F1@0.5={best['overall']['iou_50']['f1']:.4f}")


def export(args):
    rows = manifest(args.manifest)
    require(len(rows) == args.expected_count, f"Expected {args.expected_count} photos, got {len(rows)}")
    selection = read_json(args.selection)
    run_dir = Path(args.run)
    meta = read_json(run_dir/"run.json")
    require(meta["inference"] == selection["inference"], "Contest inference differs from the frozen configuration")
    require(meta["manifest_sha256"] == file_hash(args.manifest), "Contest manifest differs from inference")
    require(meta["config_hash"] == digest(meta["inference"]), "Invalid run hash")
    predictions = index_rows(read_jsonl(run_dir/"predictions.jsonl"))
    require(set(predictions) == {photo_key(r["photo_id"]) for r in rows}, "Missing or unknown prediction IDs")
    exported = []
    for row in rows:
        key = photo_key(row["photo_id"])
        p = predictions[key]
        require("error" in p and p["error"] is None, f"{key}: resolve processing error before submission")
        require(p.get("config_hash") == meta["config_hash"], "Mixed run configurations")
        require(p.get("image_sha256") == meta["image_sha256"][key], "Image hash mismatch")
        boxes = postprocess(p.get("boxes"), selection["postprocess"]["threshold"], selection["postprocess"]["nms_iou"])
        exported.append({"photo_id": row["photo_id"],
                         "boxes": [{k: b[k] for k in ("left", "top", "width", "height")} for b in boxes],
                         "error": None})
    # Check final bytes before installing the actual submission.
    import json
    payload = "".join(json.dumps(r, ensure_ascii=False, allow_nan=False)+"\n" for r in exported).encode()
    require(len(payload) <= 5*1024*1024, "Submission exceeds 5 MiB")
    write_jsonl(args.output, exported)
    write_json(str(args.output)+".audit.json", dict(
        submission_sha256=file_hash(args.output), source_predictions_sha256=file_hash(run_dir/"predictions.jsonl"),
        selection_sha256=file_hash(args.selection), count=len(exported),
        note="Export uses automatic predictions and frozen postprocessing; do not manually edit Contest boxes."))
    print(f"Validated {len(exported)} unique photos; {len(payload)} bytes; saved {args.output}")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    for name, func in (("score", score_command), ("experiment", experiment)):
        a = sub.add_parser(name)
        a.add_argument("--manifest", required=True); a.add_argument("--golden", required=True)
        a.add_argument("--run", required=True); a.add_argument("--output", required=True)
        a.add_argument("--threshold", type=float, default=.25); a.add_argument("--nms", type=float)
        if name == "experiment":
            a.add_argument("--factor", choices=["threshold", "nms"], required=True)
            a.add_argument("--values", type=float, nargs="+", required=True)
            a.add_argument("--hypothesis", required=True)
        a.set_defaults(func=func)
    a = sub.add_parser("select")
    a.add_argument("--reports", nargs="+", required=True); a.add_argument("--output", required=True)
    a.set_defaults(func=select)
    a = sub.add_parser("export")
    a.add_argument("--manifest", required=True); a.add_argument("--selection", required=True)
    a.add_argument("--run", required=True); a.add_argument("--output", required=True)
    a.add_argument("--expected-count", type=int, default=400)
    a.set_defaults(func=export)
    args = p.parse_args(); args.func(args)


if __name__ == "__main__":
    main()
